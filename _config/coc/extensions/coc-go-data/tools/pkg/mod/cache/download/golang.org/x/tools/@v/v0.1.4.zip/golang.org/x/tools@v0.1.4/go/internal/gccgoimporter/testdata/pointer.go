package pointer

type Int8Ptr *int8
